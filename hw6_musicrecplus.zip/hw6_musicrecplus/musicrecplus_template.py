# NAME:     
# PLEDGE:   

from cs115 import *



MAIN_FILE='musicRecPlus.txt'

## FILE READING/WRITING FUNCTIONS: DO NOT TOUCH

def loadUsers(fileName):
    ''' Reads in a file of stored users' preferences stored
         in the file 'fileName'.
         Returns a dictionary containing a mapping of user
         names to a list of preferred artists'''
    file = open(fileName, 'r')
    userDict = {}
    for line in file:
        # Read and parse a single line
        [userName, bands] = line.strip().split(":")
        bandList = bands.split(",")
        bandList.sort()
        userDict[userName] = bandList
    file.close() 
    return userDict

def getPreferences():
    preferences=[]
    newPref=input("Enter an artist that you like (Enter to finish): \n")
    while newPref!='':
        preferences.append(newPref.strip().title())
        newPref=input("Enter an artist that you like (Enter to finish): \n")
    preferences.sort()
    return preferences

def saveUserPreferences(userName, prefs, userMap, fileName):
    ''' Writes all of the user preferences to the file.
         Returns nothing. '''
    userMap[userName] = prefs
    file = open(fileName, "w")
    for user in userMap:
        toSave = str(user) + ":" + ",".join(userMap[user]) + \
            "\n"
        file.write(toSave)
    file.close()



## TODO: write the rest of your functions here, and use them in musicRecPlus()




def musicRecPlus():
    try:
        userMap=loadUsers(MAIN_FILE)
    except FileNotFoundError:
        file=open('musicrecplus.txt','w')
        userMap=loadUsers(MAIN_FILE)
    print("Welcome to Music Reccomender+!")
    userName=input("Enter your name (put a $ symbol after your name if you wish your preferences to remain private): \n")



    if userName not in userMap:
        userMap[userName]=getPreferences()
    

    while True:
        option=input("Enter a letter to choose an option: \ne - Enter preferences\nr - Get recommendations\np - Show most popular artists\nh - How popular is the most popular\nm - Which user has the most likes\nq - Save and quit\n")

        if option=='e':
            pass #TODO: implement me!
        elif option=='r':
            pass #TODO: implement me!
        elif option=='p':
            pass #TODO: implement me!
        elif option=='h':
            pass #TODO: implement me!
        elif option=='m':
            pass #TODO: implement me!
        elif option=='q':
            saveUserPreferences(userName,userMap[userName],userMap,MAIN_FILE)
            break
        else:
            pass

musicRecPlus()