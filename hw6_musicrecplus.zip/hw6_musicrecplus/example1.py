Python 3.7.0 (v3.7.0:1bf9cc5093, Jun 26 2018, 23:26:24) 
[Clang 6.0 (clang-600.0.57)] on darwin
Type "copyright", "credits" or "license()" for more information.
>>> 
============= RESTART: /Users/Kaitlyn/Downloads/musicrecplus.py =============
Enter your name (put a $ symbol after your name if you wish your preferences to remain private):
Steph Oro
Enter an artist that you like (Enter to finish):
Fun.
Enter an artist that you like (Enter to finish):
TMBG
Enter an artist that you like (Enter to finish):
Gotye
Enter an artist that you like (Enter to finish):

Enter a letter to choose an option:
e - Enter preferences
r - Get recommendations
p - Show most popular artists
h - How popular is the most popular
m - Which user has the most likes
q - Save and quit
r
No recommendations available at this time.
Enter a letter to choose an option:
e - Enter preferences
r - Get recommendations
p - Show most popular artists
h - How popular is the most popular
m - Which user has the most likes
q - Save and quit
p
Fun.
Gotye
Tmbg
Enter a letter to choose an option:
e - Enter preferences
r - Get recommendations
p - Show most popular artists
h - How popular is the most popular
m - Which user has the most likes
q - Save and quit
h
1
Enter a letter to choose an option:
e - Enter preferences
r - Get recommendations
p - Show most popular artists
h - How popular is the most popular
m - Which user has the most likes
q - Save and quit
m
Steph Oro
Enter a letter to choose an option:
e - Enter preferences
r - Get recommendations
p - Show most popular artists
h - How popular is the most popular
m - Which user has the most likes
q - Save and quit
q
>>> 
